#pragma once

#include "Face.h"
#include "UltraMeshExportImport.h"



class ULTRAMESH_API UltraVertex
{
public:
	UltraVertex(Eigen::Vector3d position);
	void MoveTo(Eigen::Vector3d& newPosition);
	void AddEdgeIndex(int index);
	Eigen::Vector3d Position() { return m_position; }
	std::set<int> Edges() { return m_connectedEdges; }
	int Edge(int index);
	void SetStatus(int status) { m_status = status; }
	int Status() { return m_status; }

	int m_index = -1;
	Eigen::Vector3d m_position = { 0.0, 0.0, 0.0 };
	Eigen::Vector3d m_normal = { 0.0, 0.0, 0.0 };
	std::set<int> m_connectedEdges;
	double m_curavature = 0.0;
	double m_thickness = 0.0;
	int m_status = FLAG_RESET;
};

