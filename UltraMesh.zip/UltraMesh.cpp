#include "UltraMesh.h"



typedef struct VVF
{
public:
	VVF() { ; }
	VVF(int v1, int v2, int f, int i)
	{
		m_v1 = v1;
		m_v2 = v2;
		m_f = f;
		m_i = i;
	}
	int m_v1;
	int m_v2;
	int m_f;
	int m_i;
}VVF;

UltraMesh::UltraMesh()
{
	m_vertices.clear();
	m_faces.clear();
	m_edges.clear();
}


void UltraMesh::MapEdges()
{
	bool verbose = false;
	m_edges.clear();
	for (size_t idx = 0; idx < m_faces.size(); idx++)
	{
		m_edges.push_back(UltraEdge(m_faces[idx].m_vertices[0], m_faces[idx].m_vertices[1], (int)idx));
		m_edges.push_back(UltraEdge(m_faces[idx].m_vertices[1], m_faces[idx].m_vertices[2], (int)idx));
		m_edges.push_back(UltraEdge(m_faces[idx].m_vertices[2], m_faces[idx].m_vertices[0], (int)idx));
	}
	std::vector <VVF> map1;							// Maps all Edges V1->V2 (direct)
	std::vector <VVF> map2;							// Maps all Edges V2->V1 (reversed)

	map1.resize(m_faces.size() * 3);								// Memory upfront allocation
	map2.resize(m_faces.size() * 3);
	
	int mapIndex = 0;

	// The algorithm runs over all Faces and builds direct and reversed map vectors
	for (int iFace = 0; iFace < m_faces.size(); iFace++)
	{
		UltraFace face = m_faces[iFace];
		map1[mapIndex] = VVF(face.m_vertices[0], face.m_vertices[1], iFace, mapIndex);
		map2[mapIndex] = VVF(face.m_vertices[1], face.m_vertices[0], iFace, mapIndex);
		mapIndex++;
		map1[mapIndex] = VVF(face.m_vertices[1], face.m_vertices[2], iFace, mapIndex);
		map2[mapIndex] = VVF(face.m_vertices[2], face.m_vertices[1], iFace, mapIndex);
		mapIndex++;
		map1[mapIndex] = VVF(face.m_vertices[2], face.m_vertices[0], iFace, mapIndex);
		map2[mapIndex] = VVF(face.m_vertices[0], face.m_vertices[2], iFace, mapIndex);
		mapIndex++;
	}
	//Sorting both maps in ascending order v1 then v2
	sort(map1.begin(), map1.end(), [](const VVF v1, const VVF v2)
	{
		if (v1.m_v1 == v2.m_v1)
			return v1.m_v2 < v2.m_v2;
		else
			return v1.m_v1 < v2.m_v1;
	});
	sort(map2.begin(), map2.end(), [](const VVF v1, const VVF v2)
	{
		if (v1.m_v1 == v2.m_v1)
			return v1.m_v2 < v2.m_v2;
		else
			return v1.m_v1 < v2.m_v1;
	});
	// As both maps are sorted, every line consists of two related faces of
	// both direct and reversed Edges, therefore twin index i2 can be set
	for (int iMap = 0; iMap < map1.size(); iMap++)
	{
		m_edges[map1[iMap].m_i].SetTwin(map2[iMap].m_i);
		m_edges[map2[iMap].m_i].SetTwin(map1[iMap].m_i);
	}
}

void UltraMesh::CalcFaces()
{
	for (auto& face : m_faces)
		face.CalcPlane(m_vertices[face.m_vertices[0]].m_position,
			m_vertices[face.m_vertices[1]].m_position,
			m_vertices[face.m_vertices[2]].m_position);
}

void UltraMesh::CalcNormals(bool byArea)
{
	for (auto vertex : m_vertices)
	{
		vertex.m_normal.Zero();
		for (auto edgeI : vertex.m_connectedEdges)			// Loop over touching faces
		{
			auto& edge = m_edges[edgeI];						// Touching face
			Eigen::Vector3d norm = m_faces[edge.m_idxFace].Normal();		// Touching face norm
			bool unique = true;
			for (auto edgeJ = vertex.m_connectedEdges.begin(); *edgeJ != edgeI; edgeJ++)
			{
				auto edge2 = m_edges[*edgeJ];						// Touching face
				Eigen::Vector3d norm2 = m_faces[edge2.m_idxFace].Normal();
				unique &= (norm.dot(norm2) < 0.999);
			}
			if (byArea)
				norm *= m_faces[edge.m_idxFace].m_area;					// Normal is weighted by each touching face area
			if (unique)
				vertex.m_normal += norm;
		}

		vertex.m_normal.normalize();													// Keep as 1 unit length
	}
}

Bounds* UltraMesh::CalcBounds()
{
	for (int i = 0; i < 6; i++)
		m_bounds[i] = (i % 2 == 0) ? DBL_MAX : -DBL_MAX;

	for (auto& vertex : m_vertices)
	{
		m_bounds[0] = std::min(m_bounds[0], vertex.m_position[0]);
		m_bounds[1] = std::max(m_bounds[1], vertex.m_position[0]);
		m_bounds[2] = std::min(m_bounds[2], vertex.m_position[1]);
		m_bounds[3] = std::max(m_bounds[3], vertex.m_position[1]);
		m_bounds[4] = std::min(m_bounds[4], vertex.m_position[2]);
		m_bounds[5] = std::max(m_bounds[5], vertex.m_position[2]);
	}
	return &m_bounds;
}

void UltraMesh::CalcBuckets()
{
	// get mesh bounding box
	CalcBounds();
	// calculate optimal bucket size
	int numberOfFaces = (int)m_faces.size();
	int maxRow =  (int)(sqrt(sqrt(numberOfFaces)));

	// calculate cells size and repetitions per axis
	double cellSize = std::max((m_bounds[1] - m_bounds[0]) / maxRow,
		std::max((m_bounds[3] - m_bounds[2]) / maxRow, (m_bounds[5] - m_bounds[4]) / maxRow)) + 1;

	int NX = (int)((m_bounds[1] - m_bounds[0]) / cellSize + 1);
	int NY = (int)((m_bounds[3] - m_bounds[2]) / cellSize + 1);
	int NZ = (int)((m_bounds[5] - m_bounds[4]) / cellSize + 1);

	double cellX = (m_bounds[1] - m_bounds[0]) / NX;
	double cellY = (m_bounds[3] - m_bounds[2]) / NY;
	double cellZ = (m_bounds[5] - m_bounds[4]) / NZ;

	// create array of buckets
	Bounds newBounds;
	for (int i = 0; i < NX; i++)
	{
		newBounds[4] = m_bounds[4] + i * cellZ - EPSILON6;
		newBounds[5] = newBounds[4] + cellZ + 2 * EPSILON6;
		for (int j = 0; j < NY; j++)
		{
			newBounds[2] = m_bounds[2] + j * cellY - EPSILON6;
			newBounds[3] = newBounds[2] + cellY + 2 * EPSILON6;
			for (int k = 0; k < NX; k++)
			{
				newBounds[0] = m_bounds[0] + k * cellX - EPSILON6;
				newBounds[1] = newBounds[0] + cellX + 2 * EPSILON6;
				m_buckets.push_back(Bucket(newBounds, k, j, i));
			}
		}
	}

	// add triangles to buckets. Since triangles are way smaller than the bucket size, we
	// can add triangles to neighboring buckets 
	// TBD add triangles to buckets if one of the triangle edges cuts corner in the bucket

	for (int iF = 0; iF < m_faces.size(); iF++)
	{
		UltraFace face = m_faces[iF];
		for (int iV = 0; iV < 3; iV++)
		{
			UltraVertex vertex = m_vertices[face.Vertices()[iV]];
			int indexX = (int)(std::max(0.0, vertex.Position()[0] - m_bounds[0] - EPSILON6) / cellX);
			int indexY = (int)(std::max(0.0, vertex.Position()[1] - m_bounds[2] - EPSILON6) / cellY);
			int indexZ = (int)(std::max(0.0, vertex.Position()[2] - m_bounds[4] - EPSILON6) / cellZ);

			int stride = indexZ * NX * NY + indexY * NX + indexX;

			Bucket& bucket = m_buckets[stride];
			if (bucket.IsInside(vertex.m_position))
				bucket.m_triangles.insert(iF);
		}
	}
}

std::vector<UltraFace> UltraMesh::IntersectWithRay(Eigen::Vector3d& origin, Eigen::Vector3d& direction)
{
	std::vector<UltraFace> result;
	direction.normalize();
    Bucket whole(m_bounds, -1, -1, -1);
    if (whole.IntersectWithRay(origin, direction))
    {
        std::vector<Bucket> intersected;
        for (size_t idx = 0; idx < m_buckets.size(); idx++)
        {
            Bucket bucket = m_buckets[idx];
            if ((bucket.m_triangles.size() > 0) && (bucket.IntersectWithRay(origin, direction)))
            {
                intersected.push_back(bucket);
            }
        }
        //printf("Ray from %f %f %f to %f %f %f\n", origin[0], origin[1], origin[2],
        //	direction[0], direction[1], direction[2]);
        int counter = 0;
        for (auto bucket : intersected)
        {
            //printf("Bucket %d %d %d\n", bucket.m_gridLocation[0], bucket.m_gridLocation[1], bucket.m_gridLocation[2]);
            for (int i = 0; i < (int)bucket.m_triangles.size(); i++)
            {
                std::set<int>::iterator it = bucket.m_triangles.begin();
                std::advance(it, i);
                UltraFace triangle = m_faces[*it];
                Eigen::Vector3d hit = { 0.0, 0.0, 0.0 };
                if (triangle.IntersectWithRay(m_vertices, origin, direction, hit))
                {
                    counter++;
                    //printf("%3d) intersect face %6d at: %f %f %f\n ", counter, *it, hit[0], hit[1], hit[2]);
                    result.push_back(m_faces[*it]);
                }
            }

        }
    }
	return result;
}


Bucket::Bucket(Bounds bounds, int idxX, int idxY, int idxZ)
{
	memcpy(&m_bounds[0], &bounds[0], sizeof(Bounds));
	m_gridLocation = { idxX, idxY, idxZ };
}

bool Bucket::IsInside(Eigen::Vector3d point)
{
	return !(point[0] < m_bounds[0] || point[0] > m_bounds[1] ||
		point[1] < m_bounds[2] || point[1] > m_bounds[3] ||
		point[2] < m_bounds[4] || point[2] > m_bounds[5]);
}

bool Bucket::IntersectWithRay(Eigen::Vector3d& origin, Eigen::Vector3d& direction)
{
	Eigen::Vector3d invDir = { 1.0 / direction[0], 1.0 / direction[1], 1.0 / direction[2] };
	Eigen::Vector3i sign = { invDir[0] < 0, invDir[1] < 0, invDir[2] < 0 };

	double tmin, tmax, tymin, tymax, tzmin, tzmax;

	tmin = (m_bounds[sign[0]] - origin[0]) * invDir[0];
	tmax = (m_bounds[1 - sign[0]] - origin[0]) * invDir[0];
	tymin = (m_bounds[2 + sign[1]] - origin[1]) * invDir[1];
	tymax = (m_bounds[3 - sign[1]] - origin[1]) * invDir[1];

	if ((tmin > tymax) || (tymin > tmax))
		return false;
	if (tymin > tmin)
		tmin = tymin;
	if (tymax < tmax)
		tmax = tymax;

	tzmin = (m_bounds[4 + sign[2]] - origin[2]) * invDir[2];
	tzmax = (m_bounds[5 - sign[2]] - origin[2]) * invDir[2];

	if ((tmin > tzmax) || (tzmin > tmax))
		return false;
	if (tzmin > tmin)
		tmin = tzmin;
	if (tzmax < tmax)
		tmax = tzmax;
		return true;
}

