#include "Vertex.h"

UltraVertex::UltraVertex(Eigen::Vector3d position)
{
	m_position = position;
	m_connectedEdges.clear();
}


void UltraVertex::AddEdgeIndex(int index)
{
	m_connectedEdges.insert(index);
}

void UltraVertex::MoveTo(Eigen::Vector3d& newPosition)
{
	m_position = newPosition;
}


int UltraVertex::Edge(int index)
{
	std::set<int>::iterator it = m_connectedEdges.begin();
	std::advance(it, index);
	return *it;
}

